export const environment = {
  production: true,
  watchlistEndpoint: 'http://localhost:8081/api/news',
  categoryEndpoint: 'http://localhost:8081/api/news/category',
  topnewsEndpoint: 'http://localhost:8081/api/news/topNews',
  searchEndpoint: 'http://localhost:8081/api/news/search'
};
