export interface User {
    userId: string;
    password: string;
    firstName?: string;
    lastName?: string;
}